# Preparamente — LP limpa para análise

Esta pasta foi filtrada a partir do export do Simply Static.

## Objetivo
Fornecer para uma IA apenas os arquivos que participam diretamente da renderização da landing page:
- `index.html`
- CSS carregado pela página e arquivos CSS referenciados por esses CSS
- JavaScript carregado diretamente pela página
- imagens, fontes e outros assets referenciados pelo HTML/CSS

## Números
- Export original: 9,813 arquivos
- Pacote filtrado: 118 arquivos
- Vídeo excluído: `wp-content/uploads/2026/07/Video-propaganda-site.mp4` (~100.8 MB), pois ultrapassa o limite comum de arquivo individual do GitHub e não é necessário para investigar CSS/layout.

## Importante
A estrutura `wp-content/` e `wp-includes/` foi preservada para que os caminhos do `index.html` continuem correspondendo ao export original.

O script externo `https://www.greenflame.dev/widget.js` continua referenciado no HTML, mas não foi incluído porque é externo ao export.

## Arquivos especialmente relevantes para problemas de largura/margem/responsividade
- `index.html`
- `wp-content/uploads/elementor/css/custom-frontend.min.css`
- `wp-content/uploads/elementor/css/base-desktop.css`
- `wp-content/uploads/elementor/css/local-2363-frontend-desktop.css`
- `wp-content/uploads/elementor/css/local-2363-frontend-laptop.css`
- `wp-content/uploads/elementor/css/local-2363-frontend-tablet.css`
- `wp-content/uploads/elementor/css/base-mobile.css`
- `wp-content/uploads/elementor/css/local-2363-frontend-mobile.css`
- `wp-content/themes/royal-elementor-kit/style.css`

O HTML renderizado é a melhor evidência disponível neste export para a estrutura visual da página. O export estático não contém o banco de dados/configuração editável do Elementor.
